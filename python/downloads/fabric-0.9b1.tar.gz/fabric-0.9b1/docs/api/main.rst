=====================
Command-Line Behavior
=====================

.. automodule:: fabric.main
    :members:
