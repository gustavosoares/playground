=====
State
=====

.. automodule:: fabric.state
    :members:
